module.exports = {
    dialect: 'postgres',
    host: 'localhost',
    username: 'usuario',
    password: '123',
    database: 'api-node',
    define: {
        timestamps: true,
        underscored: true
    }
}